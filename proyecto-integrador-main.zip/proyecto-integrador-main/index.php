<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Menu</title>
</head>
<body>
    <div class="container-fluid">
        <legend>Index</></legend>
        <a href="/login_utec/justificantes.php">Login</a><br>
        <a href="/login_utec/solicitud.php">Solicitud</a><br>
        <a href="/general/registro_alum.php">Registro de Alumnos</a> <br>
        <a href="/general/registro_docente.php">Registro de Docente</a> <br>
        <a href="/general/registro_just.php">Registro de Justificantes </a> <br>
        <a href="/insertar/insertar_alumnos.php">Insertar alumno </a> <br>
        <a href="/insertar/insertar_coordinador.php">Insertar coordinador</a> <br>
        <a href="/insertar/insertar_docente.php">Insertar profesor</a> <br>
        <a href="/general/registro_docente.php"> profesor</a> <br>
        

    </div>
</body>
</html>