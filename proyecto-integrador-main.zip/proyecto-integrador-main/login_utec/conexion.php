<?php
    $db = new SQLite3('../justificantes.db');
?>