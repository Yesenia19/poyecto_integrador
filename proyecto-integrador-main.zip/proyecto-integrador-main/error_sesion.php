
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Error session</title>
  <link rel="stylesheet" type="text/css" href="/css/stilos.css" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body class="body_insertar">

    <div class="jumbotron text-center">
    <h1 class="stiloslabel">ERROR DE SESSION, VERIFICA TU CORREO O CONTRASEÑA</h1>
    <a href="login_utec/justificantes.php">!Regresa al inicio de session!</p> 
    </div>
    


</body>
</html>